<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="collectibles" tilewidth="16" tileheight="16" tilecount="8" columns="4">
 <image source="../graphics/spritesheets/power-up.png" width="64" height="32"/>
 <tile id="0">
  <properties>
   <property name="collectible" value="machineGun"/>
   <property name="points" type="int" value="500"/>
  </properties>
 </tile>
</tileset>
